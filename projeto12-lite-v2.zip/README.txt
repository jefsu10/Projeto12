PROJETO 12 — LITE V2 MULTIUSUÁRIO

Perfis: Ravi, Manu, Livia e Professor.
Cada aluno tem progresso e dúvidas independentes neste navegador.
O Professor visualiza os três perfis.

IMPORTANTE:
Esta V2 ainda usa localStorage. Portanto, o progresso salvo no celular NÃO aparece automaticamente no computador do professor.
A próxima etapa será um banco de dados central no Raspberry.

COMO RODAR:
cd projeto12-lite-v2
python3 -m http.server 8000 --bind 0.0.0.0

Acesse:
http://localhost:8000
ou, em outro aparelho da mesma rede:
http://IP_DO_RASPBERRY:8000
