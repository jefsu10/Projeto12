const PROJECT12_DATA = {
  "ravi": {
    "name": "Ravi",
    "role": "student",
    "doneDefault": 5,
    "repertoire": [
      "Ofertório",
      "Entrega"
    ],
    "skills": {
      "Escalas": 4,
      "Acordes": 3,
      "Leitura": 2
    },
    "sessions": [
      {
        "n": 1,
        "type": "Consolidar",
        "form": "6 + 6",
        "contents": "Escalas de Dó e Sol • Acordes",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "ESCALAS E ACORDES",
            "Toque a escala de Dó maior 3 vezes e a escala de Sol maior 3 vezes. Depois monte C/Cm/C° e G/Gm/G°."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Toque o trecho 3 vezes lentamente. Se errar, isole, corrija e repita."
          ]
        ]
      },
      {
        "n": 2,
        "type": "Aprender",
        "form": "4 + 4 + 4",
        "contents": "Escalas de Ré e Lá • Leitura",
        "repertoire": "Entrega",
        "blocks": [
          [
            "4 min",
            "ESCALAS",
            "Toque as escalas de Ré e Lá maiores 2 vezes cada."
          ],
          [
            "4 min",
            "LEITURA",
            "Olhe a nota, diga o nome, encontre a tecla e toque."
          ],
          [
            "4 min",
            "ENTREGA",
            "Pratique o trecho; use mãos separadas se necessário."
          ]
        ]
      },
      {
        "n": 3,
        "type": "Corrigir",
        "form": "6 + 6",
        "contents": "Escalas de Mi e Si • Acordes",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "ESCALAS E ACORDES",
            "Toque Mi e Si maiores. Depois monte E/Em/E° e B/Bm/B°."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Trabalhe 1 ou 2 compassos difíceis e faça 3 repetições corretas."
          ]
        ]
      },
      {
        "n": 4,
        "type": "Consolidar",
        "form": "4 + 4 + 4",
        "contents": "Escala de Fá • Acordes",
        "repertoire": "Entrega",
        "blocks": [
          [
            "4 min",
            "ESCALA",
            "Toque a escala de Fá maior 3 vezes."
          ],
          [
            "4 min",
            "ACORDES",
            "Monte F/Fm/F° e revise maior, menor e diminuto em Dó ou Sol."
          ],
          [
            "4 min",
            "ENTREGA",
            "Toque o trecho inteiro sem parar por um erro pequeno."
          ]
        ]
      },
      {
        "n": 5,
        "type": "Revisar",
        "form": "3 + 3 + 3 + 3",
        "contents": "Escalas • Acordes • Leitura",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "3 min",
            "ESCALAS",
            "Toque Dó, Ré, Mi e Fá maiores."
          ],
          [
            "3 min",
            "ACORDES",
            "Escolha 2 tônicas e monte maior, menor e diminuto."
          ],
          [
            "3 min",
            "LEITURA",
            "Reconheça notas em clave de Sol."
          ],
          [
            "3 min",
            "OFERTÓRIO",
            "Toque e identifique onde trava."
          ]
        ]
      },
      {
        "n": 6,
        "type": "Performar",
        "form": "6 + 6",
        "contents": "Escalas de Sol, Lá e Si",
        "repertoire": "Ofertório + Entrega",
        "blocks": [
          [
            "6 min",
            "ESCALAS",
            "Toque Sol, Lá e Si maiores. Repita 2 vezes a mais difícil."
          ],
          [
            "6 min",
            "MÚSICAS",
            "Faça 3 minutos de Ofertório e 3 de Entrega. Mantenha o pulso."
          ]
        ]
      },
      {
        "n": 7,
        "type": "Consolidar",
        "form": "6 + 6",
        "contents": "Escalas de Dó, Ré e Sol • Acordes",
        "repertoire": "Entrega",
        "blocks": [
          [
            "6 min",
            "ESCALAS E ACORDES",
            "Toque Dó, Ré e Sol maiores. Monte C/Cm/C°, D/Dm/D° e G/Gm/G°."
          ],
          [
            "6 min",
            "ENTREGA",
            "Faça 1 execução lenta e 3 repetições mantendo o pulso."
          ]
        ]
      },
      {
        "n": 8,
        "type": "Corrigir",
        "form": "4 + 4 + 4",
        "contents": "Escalas de Mi, Fá e Lá • Leitura",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "4 min",
            "ESCALAS",
            "Toque Mi, Fá e Lá maiores."
          ],
          [
            "4 min",
            "LEITURA",
            "Diga as notas e depois toque em pulso lento."
          ],
          [
            "4 min",
            "OFERTÓRIO",
            "Divida o trecho difícil em partes menores e depois junte."
          ]
        ]
      },
      {
        "n": 9,
        "type": "Consolidar",
        "form": "6 + 6",
        "contents": "Escala de Si + revisão • Acordes",
        "repertoire": "Entrega",
        "blocks": [
          [
            "6 min",
            "ESCALAS E ACORDES",
            "Toque Si maior e mais 2 escalas inseguras. Monte maior, menor e diminuto."
          ],
          [
            "6 min",
            "ENTREGA",
            "Toque, corrija os pontos problemáticos e finalize o trecho inteiro."
          ]
        ]
      },
      {
        "n": 10,
        "type": "Revisar",
        "form": "3 + 3 + 3 + 3",
        "contents": "Escalas • Acordes • Leitura",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "3 min",
            "ESCALAS",
            "Escolha 3 escalas maiores."
          ],
          [
            "3 min",
            "ACORDES",
            "Escolha 3 tônicas e monte um tipo de acorde em cada."
          ],
          [
            "3 min",
            "LEITURA",
            "Leia notas em clave de Sol."
          ],
          [
            "3 min",
            "OFERTÓRIO",
            "Toque com ritmo regular."
          ]
        ]
      },
      {
        "n": 11,
        "type": "Integrar",
        "form": "6 + 6",
        "contents": "Escalas • Formação de acordes",
        "repertoire": "Ofertório + Entrega",
        "blocks": [
          [
            "6 min",
            "ESCALAS E ACORDES",
            "Escolha 3 escalas e, nas mesmas tônicas, monte maior, menor e diminuto."
          ],
          [
            "6 min",
            "MÚSICAS",
            "Faça 3 minutos de Ofertório e 3 de Entrega."
          ]
        ]
      },
      {
        "n": 12,
        "type": "Performar",
        "form": "6 + 6",
        "contents": "Revisão Dó a Si • Acordes",
        "repertoire": "Ofertório + Entrega",
        "blocks": [
          [
            "6 min",
            "REVISÃO",
            "Toque as escalas de Dó a Si e monte 2 acordes maiores, 2 menores e 2 diminutos."
          ],
          [
            "6 min",
            "PERFORMANCE",
            "Toque Ofertório e Entrega como apresentação."
          ]
        ]
      }
    ]
  },
  "manu": {
    "name": "Manu",
    "role": "student",
    "doneDefault": 7,
    "repertoire": [
      "Ofertório",
      "Imagine",
      "Billie Jean"
    ],
    "skills": {
      "Escalas": 4,
      "Acordes": 4,
      "Leitura": 3,
      "Ritmo": 3
    },
    "sessions": [
      {
        "n": 1,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Trabalhe continuidade, trechos difíceis e trocas de acordes."
          ]
        ]
      },
      {
        "n": 2,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Imagine",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "IMAGINE",
            "Trabalhe cifras, leitura de notas e ritmo, mantendo pulsação."
          ]
        ]
      },
      {
        "n": 3,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Billie Jean",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "BILLIE JEAN",
            "Trabalhe padrão rítmico, precisão e repetição sem acelerar."
          ]
        ]
      },
      {
        "n": 4,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Trabalhe continuidade, trechos difíceis e trocas de acordes."
          ]
        ]
      },
      {
        "n": 5,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Imagine",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "IMAGINE",
            "Trabalhe cifras, leitura de notas e ritmo, mantendo pulsação."
          ]
        ]
      },
      {
        "n": 6,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Billie Jean",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "BILLIE JEAN",
            "Trabalhe padrão rítmico, precisão e repetição sem acelerar."
          ]
        ]
      },
      {
        "n": 7,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Trabalhe continuidade, trechos difíceis e trocas de acordes."
          ]
        ]
      },
      {
        "n": 8,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Imagine",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "IMAGINE",
            "Trabalhe cifras, leitura de notas e ritmo, mantendo pulsação."
          ]
        ]
      },
      {
        "n": 9,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Billie Jean",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "BILLIE JEAN",
            "Trabalhe padrão rítmico, precisão e repetição sem acelerar."
          ]
        ]
      },
      {
        "n": 10,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Trabalhe continuidade, trechos difíceis e trocas de acordes."
          ]
        ]
      },
      {
        "n": 11,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Imagine",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "IMAGINE",
            "Trabalhe cifras, leitura de notas e ritmo, mantendo pulsação."
          ]
        ]
      },
      {
        "n": 12,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Escalas • Acordes • Inversões • Leitura/Ritmo",
        "repertoire": "Billie Jean",
        "blocks": [
          [
            "6 min",
            "FUNDAMENTOS",
            "Trabalhe escalas e acordes do ciclo. Inclua 1ª inversão em acordes maiores já seguros."
          ],
          [
            "6 min",
            "BILLIE JEAN",
            "Trabalhe padrão rítmico, precisão e repetição sem acelerar."
          ]
        ]
      }
    ]
  },
  "livia": {
    "name": "Livia",
    "role": "student",
    "doneDefault": 3,
    "repertoire": [
      "Ofertório",
      "Entrega",
      "Bendita Segurança",
      "Digno é o Senhor"
    ],
    "skills": {
      "Tonalidades": 3,
      "Harmonia": 4,
      "Inversões": 4,
      "Ritmo": 3,
      "Leitura": 3
    },
    "sessions": [
      {
        "n": 1,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 2,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Entrega",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "ENTREGA",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 3,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Bendita Segurança",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "BENDITA SEGURANÇA",
            "Trabalhe o compasso 6/8 sentindo 1-2-3 / 4-5-6 e mantendo as trocas no pulso."
          ]
        ]
      },
      {
        "n": 4,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Digno é o Senhor",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "DIGNO É O SENHOR",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 5,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 6,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Entrega",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "ENTREGA",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 7,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Bendita Segurança",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "BENDITA SEGURANÇA",
            "Trabalhe o compasso 6/8 sentindo 1-2-3 / 4-5-6 e mantendo as trocas no pulso."
          ]
        ]
      },
      {
        "n": 8,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Digno é o Senhor",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "DIGNO É O SENHOR",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 9,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Ofertório",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "OFERTÓRIO",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 10,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Entrega",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "ENTREGA",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      },
      {
        "n": 11,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Bendita Segurança",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "BENDITA SEGURANÇA",
            "Trabalhe o compasso 6/8 sentindo 1-2-3 / 4-5-6 e mantendo as trocas no pulso."
          ]
        ]
      },
      {
        "n": 12,
        "type": "Estudo guiado",
        "form": "6 + 6",
        "contents": "Tonalidades • I-IV-V • Inversões • Leitura/Ritmo",
        "repertoire": "Digno é o Senhor",
        "blocks": [
          [
            "6 min",
            "TONALIDADE E HARMONIA",
            "Escolha um dos 7 tons. Diga as alterações, toque a escala, monte I-IV-V e use 1ª/2ª inversões."
          ],
          [
            "6 min",
            "DIGNO É O SENHOR",
            "Aplique inversões próximas, continuidade e leitura/cifras no trecho estudado."
          ]
        ]
      }
    ]
  },
  "professor": {
    "name": "Professor",
    "role": "teacher"
  }
};