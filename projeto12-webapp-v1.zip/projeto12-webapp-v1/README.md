# Projeto 12 — Web App V1

Protótipo funcional local do Projeto 12 em Next.js.

## Linux Mint

1. Instale Node.js 20.9 ou superior.
2. Abra um terminal nesta pasta.
3. Rode:

```bash
npm install
npm run dev
```

4. Abra `http://localhost:3000`.

## Transferir para o Linux

### Pen drive / rede
Copie a pasta inteira `projeto12-webapp-v1` ou o arquivo ZIP.

### GitHub (recomendado)
Crie um repositório, envie estes arquivos e no Linux use `git clone`.

## Próxima etapa
Conectar Supabase para login real, banco, sessões, dúvidas e progresso dos alunos.
