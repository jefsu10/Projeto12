import './globals.css'
export const metadata={title:'Projeto 12',description:'Web App Projeto 12'}
export default function RootLayout({children}){return <html lang="pt-BR"><body>{children}</body></html>}
