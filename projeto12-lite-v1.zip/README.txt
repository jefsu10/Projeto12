PROJETO 12 LITE V1

Versão leve para Raspberry Pi 3 ARM 32-bit.
Não precisa de Node, npm, Next.js nem compilação.

No Raspberry:
1. Entre nesta pasta.
2. Rode:
   python3 -m http.server 8000 --bind 0.0.0.0
3. Abra no próprio Raspberry:
   http://localhost:8000
4. Para acessar de celular/computador na mesma rede:
   hostname -I
   e abra http://IP_DO_RASPBERRY:8000

O progresso desta V1 é demonstrativo e fica salvo somente no navegador (localStorage).
